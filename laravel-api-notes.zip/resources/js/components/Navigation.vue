<script setup>
import { useStore } from "vuex";
const store = useStore()
</script>

<template>
    <div class="flex items-center justify-center px-3 py-3 border-b border-gray-300">
        <div @click="store.dispatch('logout')" class="flex justify-self-start" v-if="store.getters.isLoggedIn">Logout</div>
        <router-link to="/" class="flex items-center space-x-1 mx-auto">
            <svg width="32" height="32" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M5.5 19.8333H10.5C10.9644 19.8333 11.1966 19.8333 11.3916 19.859C12.7378 20.0362 13.7971 21.0956 13.9743 22.4418C14 22.6367 14 22.8689 14 23.3333V10.6667C14 7.83824 14 6.42403 13.1213 5.54535C12.2426 4.66667 10.8284 4.66667 8 4.66667H5.5C4.55719 4.66667 4.08579 4.66667 3.79289 4.95956C3.5 5.25245 3.5 5.72386 3.5 6.66667V17.8333C3.5 18.7761 3.5 19.2475 3.79289 19.5404C4.08579 19.8333 4.55719 19.8333 5.5 19.8333Z" fill="#F2F2F2" stroke="black" stroke-width="1.5"/>
                <path d="M22.5 19.8333H17.5C17.0356 19.8333 16.8034 19.8333 16.6084 19.859C15.2622 20.0362 14.2029 21.0956 14.0257 22.4418C14 22.6367 14 22.8689 14 23.3333V10.6667C14 7.83824 14 6.42403 14.8787 5.54535C15.7574 4.66667 17.1716 4.66667 20 4.66667H22.5C23.4428 4.66667 23.9142 4.66667 24.2071 4.95956C24.5 5.25245 24.5 5.72386 24.5 6.66667V17.8333C24.5 18.7761 24.5 19.2475 24.2071 19.5404C23.9142 19.8333 23.4428 19.8333 22.5 19.8333Z" fill="#F2F2F2" stroke="black" stroke-width="1.5"/>
                <path d="M16.2105 15.6066C17.3871 15.017 18.0179 15.0357 19.1053 15.6066C20.3307 16.2364 20.9536 16.1664 22 15.6066" stroke="#333333" stroke-width="0.8" stroke-linecap="round"/>
                <path d="M16.2105 13.2512C17.3871 12.6616 18.0179 12.6803 19.1053 13.2512C20.3307 13.881 20.9536 13.811 22 13.2512" stroke="#333333" stroke-width="0.8" stroke-linecap="round"/>
                <path d="M16.2105 10.8959C17.3871 10.3062 18.0179 10.325 19.1053 10.8959C20.3307 11.5257 20.9536 11.4556 22 10.8959" stroke="#333333" stroke-width="0.8" stroke-linecap="round"/>
                <path d="M16.2105 8.54048C17.3871 7.95087 18.0179 7.96959 19.1053 8.54048C20.3307 9.17028 20.9536 9.10024 22 8.54048" stroke="#333333" stroke-width="0.8" stroke-linecap="round"/>
                <path d="M6 15.6066C7.17663 15.017 7.80743 15.0357 8.89474 15.6066C10.1202 16.2364 10.7431 16.1664 11.7895 15.6066" stroke="#333333" stroke-width="0.8" stroke-linecap="round"/>
                <path d="M6 13.2512C7.17663 12.6616 7.80743 12.6803 8.89474 13.2512C10.1202 13.881 10.7431 13.811 11.7895 13.2512" stroke="#333333" stroke-width="0.8" stroke-linecap="round"/>
                <path d="M6 10.8959C7.17663 10.3062 7.80743 10.325 8.89474 10.8959C10.1202 11.5257 10.7431 11.4556 11.7895 10.8959" stroke="#333333" stroke-width="0.8" stroke-linecap="round"/>
                <path d="M6 8.54048C7.17663 7.95087 7.80743 7.96959 8.89474 8.54048C10.1202 9.17028 10.7431 9.10024 11.7895 8.54048" stroke="#333333" stroke-width="0.8" stroke-linecap="round"/>
            </svg>
            <span class="text-2xl font-bold">Rido's Notes</span>
        </router-link>
        <router-link :to="{ name: 'NoteCreate' }" class="flex justify-self-start" v-if="store.getters.isLoggedIn">Create Note</router-link>
    </div>
</template>