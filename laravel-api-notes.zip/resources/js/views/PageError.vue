<template>
    <div class="w-screen h-screen flex items-center justify-center">
        <div class="text-3xl font-bold">
            404 | Page Not Found!
        </div>
    </div>
</template>